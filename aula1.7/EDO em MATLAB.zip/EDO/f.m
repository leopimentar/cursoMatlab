function [Y] = f(x,y)
% Fun��o f(x,y)
Y = -2.*x.*(y.^2);
%Y = x - 2.*y + 1;