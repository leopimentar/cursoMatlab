function [Y] = Yex(x)
Y = 1./(x.^2 +2);